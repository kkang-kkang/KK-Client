import * as S from "./promotionStyle";

const Promotion = () => {
  return (
    <S.PromotionContainer>
      <S.H1Box>
        <S.H1>깡깡코인맨</S.H1>
      </S.H1Box>
    </S.PromotionContainer>
  );
};

export default Promotion;
