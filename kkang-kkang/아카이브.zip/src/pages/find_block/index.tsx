import axios from "axios";
import { useEffect } from "react";
import Header from "../../components/header";

const FindBlock = () => {
  const params = new URLSearchParams(window.location.search);
  const hash = params.get("hash");
  const count = params.get("count");
  const baseUrl = process.env.REACT_APP_BASE_URL;

  useEffect(() => {
    console.log(hash);
    findBlock();
  }, [hash]);

  const findBlock = async () => {
    await axios({
      method: "get",
      url: `${baseUrl}/find-block`,
      data: {
        head: hash,
        count: count,
      },
    }).then((res) => console.log(res));
  };

  return (
    <div>
      <Header />
      <div>
        <div>header</div>
        <div>prevhash : {hash}</div>
        <div>curhash : {hash}</div>
        <div>nexthash : {hash}</div>
        <div>difficulty : {hash}</div>
        <div>nonce : {hash}</div>
        <div>timestamp : {hash}</div>
      </div>
      <div>
        <div>Body</div>
        <div>coinbaseTxHash : {hash}</div>
        <div>txHashes : {hash}</div>
      </div>
    </div>
  );
};

export default FindBlock;
