import axios from "axios";
import { useEffect } from "react";
import Header from "../../components/header";

const ListBlock = () => {
  const params = new URLSearchParams(window.location.search);
  const hash = params.get("hash");
  const baseUrl = process.env.REACT_APP_BASE_URL;

  useEffect(() => {
    console.log(hash);
    listBlock();
  }, [hash]);

  const listBlock = async () => {
    await axios({
      method: "get",
      url: `${baseUrl}/list-block?hash=${hash}`,
    }).then((res) => console.log(res));
  };

  return (
    <div>
      <Header />
      <div>curHash : {hash}</div>
      <div>prevHash : {hash}</div>
      <div>timestamp : {hash}</div>
      <div>txCount : {hash}</div>
    </div>
  );
};

export default ListBlock;
