import axios from "axios";
import { useEffect, useState } from "react";
import Header from "../../components/header";

const Test = () => {
  const sid = "WFdgrh2Xwl85EHyDAAAB";
  const [nickname, setNickname] = useState<string>();

  useEffect(() => {
    getNick();
  }, []);

  const getNick = async () => {
    const _response = await axios({
      method: "get",
      url: `/nodes/${sid}`,
    });
    setNickname(_response.data.nickname);
  };

  return (
    <div>
      <Header />
      <div>sid 값 : {sid}</div>
      <div>GetNickName 반환값 : {nickname}</div>
    </div>
  );
};

export default Test;
