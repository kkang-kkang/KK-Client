import { Link } from "react-router-dom";
import * as S from "./style";

const Header = () => {
  return (
    <S.Header>
      <Link to="/new-tx">새 거래 만들기</Link>
      <Link to="/find-tx">거래 찾기</Link>
      <Link to="/find-block">블럭 찾기</Link>
      <Link to="/list-block">블럭 리스트</Link>
      <Link to="test">프로필</Link>
    </S.Header>
  );
};

export default Header;
